package casino;

public class NincsJatekos extends RuntimeException
{
	public NincsJatekos(String s) {
		super(s);
	}
}

